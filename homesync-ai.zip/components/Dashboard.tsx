
import React from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, Tooltip, Cell, PieChart, Pie } from 'recharts';
import { Chore, Expense, TaskStatus } from '../types';

interface DashboardProps {
  chores: Chore[];
  expenses: Expense[];
}

const Dashboard: React.FC<DashboardProps> = ({ chores, expenses }) => {
  const completedCount = chores.filter(c => c.status === TaskStatus.COMPLETED).length;
  const pendingCount = chores.length - completedCount;
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const budgetGoal = 3000;
  
  const choreCategoryData = [
    { name: 'Cleaning', count: chores.filter(c => c.category === 'cleaning').length },
    { name: 'Errands', count: chores.filter(c => c.category === 'errand').length },
    { name: 'Maint.', count: chores.filter(c => c.category === 'maintenance').length },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 tracking-tight">Household Hub</h2>
          <p className="text-slate-500 font-medium">Everything under control. Here is your daily digest.</p>
        </div>
        <div className="bg-white px-4 py-2 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-2">
          <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
          <span className="text-xs font-bold text-slate-600">Smart Monitoring Active</span>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <p className="text-slate-500 text-sm font-semibold mb-2">Chore Progress</p>
          <div className="flex items-end justify-between">
            <span className="text-4xl font-bold text-blue-600">{Math.round((completedCount / (chores.length || 1)) * 100)}%</span>
            <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">{completedCount} / {chores.length} COMPLETED</span>
          </div>
          <div className="w-full bg-slate-100 h-2.5 rounded-full mt-6 overflow-hidden">
            <div 
              className="bg-blue-600 h-full rounded-full transition-all duration-1000" 
              style={{ width: `${(completedCount / (chores.length || 1)) * 100}%` }}
            />
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <p className="text-slate-500 text-sm font-semibold mb-2">Monthly Spending</p>
          <div className="flex items-end justify-between">
            <span className="text-4xl font-bold text-emerald-600">${totalExpenses.toLocaleString()}</span>
            <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">LIMIT: ${budgetGoal}</span>
          </div>
          <div className="w-full bg-slate-100 h-2.5 rounded-full mt-6 overflow-hidden">
            <div 
              className="bg-emerald-600 h-full rounded-full transition-all duration-1000" 
              style={{ width: `${Math.min((totalExpenses / budgetGoal) * 100, 100)}%` }}
            />
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <p className="text-slate-500 text-sm font-semibold mb-2">Urgent Matters</p>
          <div className="flex items-center gap-4">
            <span className="text-4xl font-bold text-rose-500">{pendingCount}</span>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-slate-700">Pending Tasks</span>
              <span className="text-[10px] text-slate-400">Action required by family</span>
            </div>
          </div>
          <div className="flex -space-x-2 mt-6">
            {[1, 2, 3].map(i => (
              <img key={i} src={`https://picsum.photos/seed/${i + 10}/50`} className="w-8 h-8 rounded-full border-2 border-white ring-1 ring-slate-100" alt="Member" />
            ))}
            <div className="w-8 h-8 rounded-full bg-slate-100 border-2 border-white ring-1 ring-slate-100 flex items-center justify-center text-[10px] font-bold text-slate-500">+1</div>
          </div>
        </div>
      </div>

      {/* Visual Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-800 mb-8 flex items-center gap-2">
            <span className="text-blue-600">📊</span> Task Distribution
          </h3>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={choreCategoryData}>
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8', fontWeight: 600 }} />
                <Tooltip cursor={{ fill: '#f1f5f9' }} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }} />
                <Bar dataKey="count" fill="#3b82f6" radius={[6, 6, 6, 6]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm relative">
          <h3 className="text-lg font-bold text-slate-800 mb-8 flex items-center gap-2">
            <span className="text-emerald-600">🥘</span> Meal Distribution
          </h3>
          <div className="h-[280px] flex items-center justify-center">
             <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                   <Pie
                      data={[
                        { name: 'Alex', value: 45 },
                        { name: 'Sam', value: 35 },
                        { name: 'Jordan', value: 20 },
                      ]}
                      innerRadius={70}
                      outerRadius={90}
                      paddingAngle={8}
                      dataKey="value"
                      stroke="none"
                   >
                      <Cell fill="#3b82f6" />
                      <Cell fill="#8b5cf6" />
                      <Cell fill="#ec4899" />
                   </Pie>
                   <Tooltip />
                </PieChart>
             </ResponsiveContainer>
             <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none mt-4">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Contribution</span>
                <span className="text-2xl font-black text-slate-700">100%</span>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
