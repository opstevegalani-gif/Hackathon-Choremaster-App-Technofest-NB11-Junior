
import React, { useState } from 'react';
import { Chore, TaskStatus, TaskPriority, FamilyMember } from '../types';
import { generateSmartChoreSchedule } from '../services/geminiService';

interface ChoreManagerProps {
  chores: Chore[];
  family: FamilyMember[];
  onUpdateChore: (chore: Chore) => void;
  onAddChores: (newChores: Chore[]) => void;
}

const ChoreManager: React.FC<ChoreManagerProps> = ({ chores, family, onUpdateChore, onAddChores }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [filter, setFilter] = useState<TaskStatus | 'ALL'>('ALL');

  const handleGenerateSchedule = async () => {
    setIsGenerating(true);
    const names = family.map(f => f.name);
    const generated = await generateSmartChoreSchedule(names, "Balanced cleaning and occasional garden maintenance");
    
    const formatted: Chore[] = generated.map((g, i) => ({
      id: Math.random().toString(36).substr(2, 9),
      title: g.title || 'Untitled Task',
      description: g.description || '',
      assignedTo: g.assignedTo || family[0].name,
      status: TaskStatus.TODO,
      priority: (g.priority as TaskPriority) || TaskPriority.MEDIUM,
      category: (g.category as any) || 'other',
      dueDate: new Date().toISOString().split('T')[0]
    }));

    onAddChores(formatted);
    setIsGenerating(false);
  };

  const filteredChores = chores.filter(c => filter === 'ALL' || c.status === filter);

  const getPriorityColor = (p: TaskPriority) => {
    switch(p) {
      case TaskPriority.HIGH: return 'bg-rose-100 text-rose-600';
      case TaskPriority.MEDIUM: return 'bg-amber-100 text-amber-600';
      case TaskPriority.LOW: return 'bg-blue-100 text-blue-600';
      default: return 'bg-slate-100 text-slate-600';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Household Chores</h2>
          <p className="text-slate-500 text-sm">Organize and assign daily routines.</p>
        </div>
        <div className="flex gap-2">
           <button 
             onClick={handleGenerateSchedule}
             disabled={isGenerating}
             className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-indigo-700 transition shadow-sm disabled:opacity-50 flex items-center gap-2"
           >
             {isGenerating ? '🤖 Thinking...' : '✨ Generate AI Routine'}
           </button>
        </div>
      </div>

      <div className="flex gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
        {(['ALL', TaskStatus.TODO, TaskStatus.IN_PROGRESS, TaskStatus.COMPLETED] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-1.5 text-xs font-semibold rounded-full transition-all whitespace-nowrap ${
              filter === f ? 'bg-slate-800 text-white' : 'text-slate-500 hover:bg-slate-100'
            }`}
          >
            {f.replace('_', ' ')}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredChores.map(chore => (
          <div key={chore.id} className="bg-white border border-slate-200 rounded-2xl p-5 hover:shadow-md transition-shadow group">
            <div className="flex justify-between items-start mb-4">
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${getPriorityColor(chore.priority)}`}>
                {chore.priority}
              </span>
              <button 
                onClick={() => onUpdateChore({
                  ...chore, 
                  status: chore.status === TaskStatus.COMPLETED ? TaskStatus.TODO : TaskStatus.COMPLETED
                })}
                className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${
                  chore.status === TaskStatus.COMPLETED ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-slate-200 hover:border-emerald-400'
                }`}
              >
                {chore.status === TaskStatus.COMPLETED && '✓'}
              </button>
            </div>
            
            <h3 className={`font-bold text-slate-800 mb-1 ${chore.status === TaskStatus.COMPLETED ? 'line-through text-slate-400' : ''}`}>
              {chore.title}
            </h3>
            <p className="text-slate-500 text-xs line-clamp-2 mb-4">{chore.description}</p>
            
            <div className="flex items-center justify-between pt-4 border-t border-slate-50">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-indigo-100 flex items-center justify-center text-[10px] font-bold text-indigo-600">
                  {chore.assignedTo[0]}
                </div>
                <span className="text-xs font-medium text-slate-600">{chore.assignedTo}</span>
              </div>
              <span className="text-[10px] text-slate-400 font-medium">Due: {chore.dueDate}</span>
            </div>
          </div>
        ))}

        {filteredChores.length === 0 && (
          <div className="col-span-full py-12 text-center border-2 border-dashed border-slate-200 rounded-3xl">
             <p className="text-slate-400 text-sm">No chores found. Try generating some with AI!</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChoreManager;
