
import { GoogleGenAI, Type } from "@google/genai";
import { Chore } from "../types";

export const generateSmartChoreSchedule = async (familyMembers: string[], housePriorities: string): Promise<Partial<Chore>[]> => {
  // Create a new GoogleGenAI instance right before making an API call to ensure it always uses the most up-to-date API key
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `Generate a realistic weekly chore schedule for a household with members: ${familyMembers.join(', ')}. 
  The priorities are: ${housePriorities}. Provide at least 5 chores with titles, descriptions, assignees, and priority levels.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              assignedTo: { type: Type.STRING },
              priority: { type: Type.STRING, description: 'LOW, MEDIUM, or HIGH' },
              category: { type: Type.STRING, description: 'cleaning, errand, maintenance, or other' }
            },
            required: ['title', 'description', 'assignedTo', 'priority', 'category']
          }
        }
      }
    });

    // Access response.text property directly as per Gemini API guidelines
    const data = JSON.parse(response.text || '[]');
    return data;
  } catch (error) {
    console.error("Gemini Error:", error);
    return [];
  }
};

export const getHouseholdAdvice = async (query: string): Promise<string> => {
  // Create a new GoogleGenAI instance right before making an API call to ensure it always uses the most up-to-date API key
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a helpful household management assistant. Give concise, practical advice for the following user request: ${query}`,
    });
    // Access response.text property directly as per Gemini API guidelines
    return response.text || "I'm sorry, I couldn't process that request.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error communicating with AI assistant.";
  }
};
